<?php
$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome to EcoRental WiFi</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      text-align: center;
      padding-top: 50px;
    }
    .box {
      background: white;
      padding: 30px;
      max-width: 500px;
      margin: auto;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    img {
      width: 200px;
      margin: 20px 0;
    }
    a.button, button {
      display: inline-block;
      margin: 15px;
      padding: 10px 20px;
      background-color: #4285f4;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      font-size: 16px;
    }
    button {
      background-color: green;
    }
  </style>
</head>
<body>
  <div class="box">
    <h2>Welcome to EcoRental Santorini 🌴</h2>
    <p>Support us by leaving a quick review 🙏</p>
    
    <a href="https://www.google.com/search?sca_esv=11c15b9305e87a82&rlz=1C1GCEA_enGR868GR868&sxsrf=AHTn8zrozlTFTF78dYv3CMNtHytzLSQ_ew:1745131871986&si=APYL9bs7Hg2KMLB-4tSoTdxuOx8BdRvHbByC_AuVpNyh0x2KzXnaZFvJo-N-myw5fDscSNdAbRu6mUGvYeIGWJ-DqbGu_9jUFL_X3QeLM6XNFGpHrq1pp0Udieq6qlsmS2fJ5Y5XpxJuIcmF5rWprUDhQz0zLtJzMg==&q=Eco+Rental+Santorini+%CE%9A%CF%81%CE%B9%CF%84%CE%B9%CE%BA%CE%AD%CF%82&sa=X&ved=2ahUKEwjyqsPqguaMAxXR2QIHHfizCGwQ0bkNegQILxAE&biw=1680&bih=881&dpr=1" target="_blank" class="button">Leave a Google Review</a>
    
    <p>Or scan to connect to Wi-Fi:</p>
    <img src="wifi_qr.png" alt="Wi-Fi QR Code">
    
    <form action="/auth/?stage=login" method="get">
      <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>" />
      <button type="submit">Continue to Wi-Fi</button>
    </form>
  </div>
</body>
</html>
